package agricultural_system;

public class DisplayEmployee {

    private final int uid;
    private final String uname;
    private final String unic;
    private final String umobile;
    private final String uaddress;
    private final String udep;
    private final String ubd;

    DisplayEmployee(int id, String name, String nic, String mobile, String address, String department, String birth) {

        this.uid = id;
        this.uname = name;
        this.unic = nic;
        this.umobile = mobile;
        this.uaddress = address;
        this.udep = department;
        this.ubd = birth;
    }

    public int getUid() {
        return uid;
    }

    public String getUname() {
        return uname;
    }

    public String getUnic() {
        return unic;
    }

    public String getUmobile() {
        return umobile;
    }

    public String getUaddress() {
        return uaddress;
    }

    public String getUdep() {
        return udep;
    }

    public String getUbd() {
        return ubd;
    }
    
    
    
    
}
