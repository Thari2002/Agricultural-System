/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agricultural_system;

/**
 *
 * @author PC
 */
public class DisplayLand {

    private final int id;
    private final String name;
    private final String numb;
    private final String size;
    private final String loca;
    private final String type;
    private final String fid;

    public DisplayLand(int id, String name, String number, String size, String location, String type, String fmid) {
        
        this.id=id;
        this.name=name;
        this.numb=number;
        this.size=size;
        this.loca=location;
        this.type=type;
        this.fid=fmid;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getNumb() {
        return numb;
    }

    public String getSize() {
        return size;
    }

    public String getLoca() {
        return loca;
    }

    public String getType() {
        return type;
    }

    public String getFid() {
        return fid;
    }
    
    
    
}
