
package agricultural_system;

//import Image.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnect2 {
    public static Connection connect()
    {
     Connection con=null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");                                
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/agriculture","root","1234567890tm");  
            System.out.println("Success!!!");
        } 
        catch (ClassNotFoundException | SQLException e) 
        {
        System.out.println("inter.DBConnect.connect()");
        }
   return con;
    }
}

