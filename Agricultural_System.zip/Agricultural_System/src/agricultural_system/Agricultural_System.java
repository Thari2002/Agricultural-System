package agricultural_system;

public class Agricultural_System {

   
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
