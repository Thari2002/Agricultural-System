/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agricultural_system;

/**
 *
 * @author PC
 */
public class DisplayBills {

    private final int bid;
    private final String pid;
    private final String name;
    private final String qty;
    private final String price;
    private final String tot;

    public DisplayBills(int id, String pid, String name, String quantity, String price, String total) {
        
        this.bid = id;
        this.pid = pid;
        this.name = name;
        this.qty = quantity;
        this.price = price;
        this.tot = total;
        
    }

    public int getBid() {
        return bid;
    }

    public String getPid() {
        return pid;
    }

    public String getName() {
        return name;
    }

    public String getQty() {
        return qty;
    }

    public String getPrice() {
        return price;
    }

    public String getTot() {
        return tot;
    }
    
    
}
