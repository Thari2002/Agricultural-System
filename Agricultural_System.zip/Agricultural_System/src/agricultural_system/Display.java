package agricultural_system;

public class Display {

    private final int fid;
    private final String uname;
    private final String unic;
    private final String umobile;
    private final String uaddress;
    private final String district;
    private final String province;
    private final String category;

    Display(int id, String name, String nic, String mobile, String address, String disct, String prov, String cate) {

        this.fid = id;
        this.uname = name;
        this.unic = nic;
        this.umobile = mobile;
        this.uaddress = address;
        this.district = disct;
        this.province = prov;
        this.category = cate;
    }

    public int getFid() {
        return fid;
    }

    public String getUname() {
        return uname;
    }

    public String getUnic() {
        return unic;
    }

    public String getUmobile() {
        return umobile;
    }

    public String getUaddress() {
        return uaddress;
    }

    public String getDistrict() {
        return district;
    }

    public String getProvince() {
        return province;
    }

    public String getCategory() {
        return category;
    }  
}
